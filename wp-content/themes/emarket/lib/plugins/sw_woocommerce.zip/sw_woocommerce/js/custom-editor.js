(function($) {
	$( window ).on( 'elementor/frontend/init', function(){
		$('.test-select2').css( 'display', 'none' );
		
	});
})(jQuery);